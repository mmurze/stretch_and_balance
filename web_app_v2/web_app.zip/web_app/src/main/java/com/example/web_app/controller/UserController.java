package com.example.web_app.controller;


import com.example.web_app.entity.UserEntity;
import com.example.web_app.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {
    private UserRepo userRepo;
    @PostMapping
    public ResponseEntity registration (@RequestBody UserEntity user){
        try {
            userRepo.save(user);
            return ResponseEntity.ok("User was created :)");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Error... (");
        }
    }

    @RequestMapping("/u")
    public ResponseEntity getUsers(){
        try {
            return ResponseEntity.ok("Server is working: ");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Error... :(");
        }
    }
}
